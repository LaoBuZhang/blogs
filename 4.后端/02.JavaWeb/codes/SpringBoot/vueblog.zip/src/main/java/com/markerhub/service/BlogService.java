package com.markerhub.service;

import com.markerhub.entity.Blog;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author LaoBuzhang
 * @since 2022-05-20
 */
public interface BlogService extends IService<Blog> {

}
