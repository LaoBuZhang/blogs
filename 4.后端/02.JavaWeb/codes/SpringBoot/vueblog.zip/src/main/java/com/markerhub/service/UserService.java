package com.markerhub.service;

import com.markerhub.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author LaoBuzhang
 * @since 2022-05-20
 */
public interface UserService extends IService<User> {

}
